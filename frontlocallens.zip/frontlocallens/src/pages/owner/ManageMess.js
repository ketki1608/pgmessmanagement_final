
import React from 'react';
import { Container, Form, Row, Col, Button } from 'react-bootstrap';
import './ManageAccount.css';
//import pgImage from '../../public/images/pg-image.jpg'; // Importing image from public/images folder

const ManageAccount = () => {
  return (
    <Container className="manage-account-container">
      <h1>Manage Mess</h1>
      <Form className="manage-account-form">
        <Form.Group as={Row} controlId="pgName" className="mb-3">
          <Form.Label column sm="2">
            Mess Name
          </Form.Label>
          <Col sm="10">
            <Form.Control type="text" placeholder="Enter PG Name" />
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="location" className="mb-3">
          <Form.Label column sm="2">
            Location
          </Form.Label>
          <Col sm="10">
            <Form.Control as="select">
              <option>Gokhalenagar</option>
              <option>Model Colony</option>
              <option>Shivaji Nagar</option>
              <option>Karve Nagar</option>
            </Form.Control>
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="description" className="mb-3">
          <Form.Label column sm="2">
            Description
          </Form.Label>
          <Col sm="10">
            <Form.Control as="textarea" rows={3} placeholder="Enter Description" />
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="price" className="mb-3">
          <Form.Label column sm="2">
            Monthly Price
          </Form.Label>
          <Col sm="10">
            <Form.Control type="number" placeholder="Enter Price" />
          </Col>
        </Form.Group>


        <Form.Group as={Row} controlId="photos" className="mb-3">
          <Form.Label column sm="2">
            Add Photos
          </Form.Label>
          <Col sm="10">
            <Form.Control type="file" multiple />
          </Col>
        </Form.Group>

        <Form.Group as={Row}>
          <Col sm={{ span: 10, offset: 2 }}>
            <Button type="submit">Submit</Button>
          </Col>
        </Form.Group>
      </Form>

      {/* PG Information Display */}
      <div className="pg-info-container">
        <Row className='rowclass'>
          <Col md="4">
            <img src={require('../../assets/images/ms2.jpeg')} alt="PG" className="pg-image" />
          </Col>
          <Col md="8" className="pg-details">
            <h2>Annapurna Khanawal</h2>
            <p>Gokhalenagar</p>
            <p className="price">₹3000/mo*</p>
            <p>Vegetarian, Non-Vegetarian</p>
            <p>One time,Two time</p>
            <Row className="pg-actions">
              <Col sm="6">
                <Button variant="success" className="w-100">Update</Button>
              </Col>
              <Col sm="6">
                <Button variant="outline-success" className="w-100">Delete</Button>
              </Col>
            </Row>
          </Col>
        </Row>


      </div>
    </Container>
  );
};

export default ManageAccount;
