
import React from 'react';
import { Container } from 'react-bootstrap';

const Members = () => (
  <Container>
    <h1>Members</h1>
    <p>Manage your members here.</p>
  </Container>
);

export default Members;
