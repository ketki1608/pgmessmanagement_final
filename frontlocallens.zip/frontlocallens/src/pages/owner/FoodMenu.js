// src/pages/owner/FoodMenu.js
import React, { useState } from 'react';
import { Container, Row, Col, Button, Modal, Form, Table } from 'react-bootstrap';
import './FoodMenu.css';
//import messImage from '../../public/images/mess-image.jpg'; // Importing image from public/images folder

const FoodMenu = () => {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <Container className="food-menu-container">
      <h1>Available Mess</h1>

      {/* Mess Information Display */}
      <div className="mess-info-container">
        <Row>
          <Col md="4">
            <img src={require('../../assets/images/ms2.jpeg')} alt="Mess" className="mess-image" />
          </Col>
          <Col md="8" className="mess-details">
            <h2>Annapurna Mess</h2>
            <p>Gokhalenagar</p>
            <p className="price">₹3000/mo*</p>
            <p>Vegetarian, Non-Vegetarian</p>
            <p>One time,Two time</p>
            <Button variant="success" onClick={handleShow}>Add Menu</Button>
          </Col>
        </Row>
      </div>

      {/* Menu List Table */}
      <div className="menu-list-container">
        <h2>Menu List</h2>
        <Table striped bordered hover className="menu-list-table">
          <thead>
            <tr>
              <th>Sr No</th>
              <th>Menu Name</th>
              <th>Price</th>
              <th>Description</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {/* Sample data */}
            <tr>
              <td>1</td>
              <td>Chicken Biryani</td>
              <td>₹250</td>
              <td>Delicious chicken biryani with raita</td>
              <td><Button variant="info">Update</Button></td>
              <td><Button variant="danger">Delete</Button></td>
            </tr>
            <tr>
              <td>2</td>
              <td>Paneer Butter Masala</td>
              <td>₹200</td>
              <td>Paneer butter masala with naan</td>
              <td><Button variant="info">Update</Button></td>
              <td><Button variant="danger">Delete</Button></td>
            </tr>
          </tbody>
        </Table>
      </div>

      {/* Add Menu Modal */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Menu</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="menuName" className="mb-3">
              <Form.Label>Menu Name</Form.Label>
              <Form.Control type="text" placeholder="Enter Menu Name" />
            </Form.Group>

            <Form.Group controlId="price" className="mb-3">
              <Form.Label>Price</Form.Label>
              <Form.Control type="number" placeholder="Enter Price" />
            </Form.Group>

            <Form.Group controlId="description" className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control as="textarea" rows={3} placeholder="Enter Description" />
            </Form.Group>

            <Form.Group controlId="image" className="mb-3">
              <Form.Label>Image</Form.Label>
              <Form.Control type="file" />
            </Form.Group>

            <Button variant="success" type="submit" className="w-100">
              Submit
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </Container>
  );
};

export default FoodMenu;
