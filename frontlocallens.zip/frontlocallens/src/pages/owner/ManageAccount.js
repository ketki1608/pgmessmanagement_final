
import React from 'react';
import { Container, Form, Row, Col, Button } from 'react-bootstrap';
import './ManageAccount.css';
//import pgImage from '../../public/images/pg-image.jpg'; // Importing image from public/images folder

const ManageAccount = () => {
  return (
    <Container className="manage-account-container">
      <h1>Manage Account</h1>
      <Form className="manage-account-form">
        <Form.Group as={Row} controlId="pgName" className="mb-3">
          <Form.Label column sm="2">
            PG Name
          </Form.Label>
          <Col sm="10">
            <Form.Control type="text" placeholder="Enter PG Name" />
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="location" className="mb-3">
          <Form.Label column sm="2">
            Location
          </Form.Label>
          <Col sm="10">
            <Form.Control as="select">
              <option>Gokhalenagar</option>
              <option>Model Colony</option>
              <option>Shivaji Nagar</option>
              <option>Karve Nagar</option>
            </Form.Control>
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="description" className="mb-3">
          <Form.Label column sm="2">
            Description
          </Form.Label>
          <Col sm="10">
            <Form.Control as="textarea" rows={3} placeholder="Enter Description" />
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="price" className="mb-3">
          <Form.Label column sm="2">
            Price
          </Form.Label>
          <Col sm="10">
            <Form.Control type="number" placeholder="Enter Price" />
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="totalBeds" className="mb-3">
          <Form.Label column sm="2">
            Total Beds
          </Form.Label>
          <Col sm="10">
            <Form.Control type="number" placeholder="Enter Total Beds" />
          </Col>
        </Form.Group>

        <Form.Group as={Row} controlId="photos" className="mb-3">
          <Form.Label column sm="2">
            Add Photos
          </Form.Label>
          <Col sm="10">
            <Form.Control type="file" multiple />
          </Col>
        </Form.Group>

        <Form.Group as={Row}>
          <Col sm={{ span: 10, offset: 2 }}>
            <Button type="submit">Submit</Button>
          </Col>
        </Form.Group>
      </Form>

      {/* PG Information Display */}
      <div className="pg-info-container">
        <Row className='rowclass'>
          <Col md="4">
            <img src={require('../../assets/images/sl2.webp')} alt="PG" className="pg-image" />
          </Col>
          <Col md="8" className="pg-details">
            <h2>Satwik Boys Pg</h2>
            <p>Gokhalenagar</p>
            <p className="price">₹5000/mo*</p>
            <p>10 Rooms Available</p>
            <p>Triple, Quadruple</p>
            <Row className="pg-actions">
              <Col sm="6">
                <Button variant="success" className="w-100">Update</Button>
              </Col>
              <Col sm="6">
                <Button variant="outline-success" className="w-100">Delete</Button>
              </Col>
            </Row>
          </Col>
        </Row>

        <Row className='rowclass'>
          <Col md="4">
            <img src={require('../../assets/images/sl3.jpg')} alt="PG" className="pg-image" />
          </Col>
          <Col md="8" className="pg-details">
            <h2>Laxmi Pg</h2>
            <p>Gokhalenagar</p>
            <p className="price">₹4000/mo*</p>
            <p>5 Rooms Available</p> 
            <p>Double, Triple, Quadruple</p>
            <Row className="pg-actions">
              <Col sm="6">
                <Button variant="success" className="w-100">Update</Button>
              </Col>
              <Col sm="6">
                <Button variant="outline-success" className="w-100">Delete</Button>
              </Col>
            </Row>
          </Col>
        </Row>

      </div>
    </Container>
  );
};

export default ManageAccount;
