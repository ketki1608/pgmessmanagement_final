import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Signup = () => {
  const [name, setName] = useState(''); 
  const [username, setUserame] = useState('');  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mobno, setMob] = useState('');
  const [type, setType] = useState('user');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/api/signup', {
        email,
        password,
        type
      });
      navigate('/signin');
    } catch (error) {
      console.error('Error signing up:', error);
    }
  };

  return (
    <div className="container mt-5">
      <h2>Sign Up</h2>
      <form onSubmit={handleSubmit}>
      <div className="form-group">
          <label>Enter Fullname</label>
          <input
            type="text"
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Enter Username</label><br/>
          <abbr title="must contain 8 or more characters that are of at least one number, and one uppercase and lowercase letter">Tip👇</abbr>
          <input pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
            type="text"
            className="form-control"
            value={username}
            onChange={(e) => setUserame(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Enter Email address</label>
          <input
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Enter Password</label><br/>
          <abbr title="must contain 8 or more characters that are of at least one number, and one uppercase and lowercase letter">Tip👇</abbr>
          <input pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Enter Mobile-No</label>
          <input pattern="[6789][0-9]{10}"
            type="text"
            className="form-control"
            value={mobno}
            onChange={(e) => setMob(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Select Type</label>
          <select
            className="form-control"
            value={type}
            onChange={(e) => setType(e.target.value)}
          >
            <option value="user">User</option>
            <option value="owner">Owner</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary" style={{marginTop:'10px'}}>Sign Up</button>
      </form>
    </div>
  );
};

export default Signup;
