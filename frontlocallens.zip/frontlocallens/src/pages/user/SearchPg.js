// src/pages/SearchPg.js
import React, { useState } from 'react';
import './SearchPg.css';
import { Container } from 'react-bootstrap';

const availablePGs = [
  {
    id: 1,
    name: 'Satwik Pg',
    location: 'Gokhalenagar',
    price: 5000,
    rooms:10,
    type:'Triple,Quadruple',
    image: '/images/sl3.jpg',
  },
  {
    id: 2,
    name: 'Laxmi Pg',
    location: 'Gokhalenagar',
    price: 4000,
    rooms:5,
    type:'Double,Triple,Quadruple',
    image: '/images/sl2.webp',
  },
];

const SearchPg = () => {
  const [location, setLocation] = useState('');
  const [price, setPrice] = useState('');
  const [showPopup, setShowPopup] = useState(false);
  const [selectedPG, setSelectedPG] = useState(null);

  const handleSearch = () => {
    // Logic to filter PGs based on location and price
  };

  const handleBookClick = (pg) => {
    setSelectedPG(pg);
    setShowPopup(true);
  };

  const handleClosePopup = () => {
    setShowPopup(false);
    setSelectedPG(null);
  };

  return (
    <Container>
      <h1 style={{marginTop:'10px'}}>Search & Book PG</h1>
      <div className="search-container">
        <div className="dropdown-container">
          <label htmlFor="location">Search by Location:</label>
          <select id="location" value={location} onChange={(e) => setLocation(e.target.value)}>
            <option value="">Choose...</option>
            <option value="gokhalenagar">Gokhalenagar</option>
            <option value="shivajinagar">Shivajinagar</option>
            <option value="modelcolony">Model Colony</option>
            <option value="karvenagar">Karvenagar</option>
          </select>
        </div>
        <div className="dropdown-container">
          <label htmlFor="price">Search by Price:</label>
          <select id="price" value={price} onChange={(e) => setPrice(e.target.value)}>
            <option value="">Choose...</option>
            <option value="5000">₹5000</option>
            <option value="4000">₹4000</option>
            <option value="3000">₹3000</option>
            <option value="6000">₹6000</option>
          </select>
        </div>
        <button className="search-button" onClick={handleSearch}>Search</button>
      </div>
      <div className="pg-list-container">
        {availablePGs.map((pg) => (
          <div className="pg-card" key={pg.id}>
            <div className="pg-image-container">
              <img src={pg.image} alt={pg.name} className="pg-image" />
            </div>
            <div className="pg-info">
              <h2>{pg.name}</h2>
              <p>{pg.location}</p>
              <p>₹{pg.price}/mo</p>
              <p>{pg.rooms}</p>
              <p>{pg.type}</p>
              <button className="book-button" onClick={() => handleBookClick(pg)}>Book</button>
            </div>
          </div>
        ))}
      </div>

      {showPopup && (
        <div className="popup">
          <div className="popup-content">
            <h2>Book PG - {selectedPG.name}</h2>
            <form>
              <div className="form-group">
                <label htmlFor="name">Name</label>
                <input type="text" id="name" required />
              </div>
              <div className="form-group">
                <label htmlFor="mobile">Mobile-No</label>
                <input type="tel" id="mobile" required />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email-ID</label>
                <input type="email" id="email" required />
              </div>
              <div className="form-group">
                <label htmlFor="government-id">Government ID</label>
                <input type="file" id="government-id" required />
              </div>
              <div className="form-group">
                <label htmlFor="date">Select Date</label>
                <input type="date" id="date" required />
              </div>
              <div className="form-group">
                <label htmlFor="payment">Payment Options</label>
                <select id="payment" required>
                  <option value="">Choose...</option>
                  <option value="credit-card">Credit Card</option>
                  <option value="debit-card">Debit Card</option>
                  <option value="net-banking">Net Banking</option>
                  <option value="upi">UPI</option>
                </select>
              </div>
              <button type="submit" className="done-button">Done</button>
              <button type="button" className="close-button" onClick={handleClosePopup}>Close</button>
            </form>
          </div>
        </div>
      )}
    </Container>
  );
};

export default SearchPg;
