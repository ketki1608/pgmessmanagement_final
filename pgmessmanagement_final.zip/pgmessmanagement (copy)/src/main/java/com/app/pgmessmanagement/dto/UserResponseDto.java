package com.app.pgmessmanagement.dto;

public class UserResponseDto {
}
